import UIKit

var hobby: [String] = ["I like to collect" ]

hobby.append("Amethyst")
hobby.append("Tiger's eye")
hobby.append("Rose quartz")
hobby.append("Clear quartz")
hobby += ["Malachite"]
for item in hobby {
    print(item)
}
